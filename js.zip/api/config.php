<?php
// File Konfigurasi Terpusat

define('DB_HOST', 'localhost');
define('DB_NAME', 'web_crudworks');
define('DB_USER', 'root');
define('DB_PASS', ''); 